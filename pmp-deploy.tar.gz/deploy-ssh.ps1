# PowerShell SSH Deployment Script for PMP Production
Write-Host "🚀 Starting SSH deployment..." -ForegroundColor Green

# Configuration - UPDATE THESE VALUES
$Server = "your-server-ip"
$User = "your-username"
$ProjectPath = "/var/www/pmp-prod"
$Domain = "your-domain.com"

Write-Host "📦 Creating deployment package..." -ForegroundColor Yellow
# Create deployment package (excluding unnecessary files)
$excludeFiles = @("node_modules", ".git", ".next", "logs", "test*", "*.log", "coverage", "validation-results.json", "tsconfig.tsbuildinfo", "tsc_errors.log")
$files = Get-ChildItem -Recurse | Where-Object { 
    $excludeFiles -notcontains $_.Name -and 
    $_.FullName -notlike "*test*" -and
    $_.FullName -notlike "*check-*" -and
    $_.FullName -notlike "*clean-*" -and
    $_.FullName -notlike "*add-*" -and
    $_.FullName -notlike "*heatmap-*" -and
    $_.FullName -notlike "*valuation-*" -and
    $_.FullName -notlike "*simple-*"
}

# Create tar.gz package
tar -czf pmp-deploy.tar.gz -C . $files.Name

Write-Host "📤 Uploading to server..." -ForegroundColor Yellow
scp pmp-deploy.tar.gz ${User}@${Server}:/tmp/

Write-Host "🔧 Deploying on server..." -ForegroundColor Yellow
ssh ${User}@${Server} @"
    # Extract deployment
    cd /tmp
    tar -xzf pmp-deploy.tar.gz -C $ProjectPath/
    
    # Install dependencies
    cd $ProjectPath
    npm ci --production
    
    # Setup database
    mkdir -p data
    cp prisma/data/premarket.db data/premarket.db
    
    # Generate Prisma client
    npx prisma generate
    
    # Run migrations
    npx prisma migrate deploy
    
    # Build application
    npm run build
    
    # Restart with PM2
    pm2 restart pmp-prod || pm2 start npm --name pmp-prod -- start
    
    # Cleanup
    rm /tmp/pmp-deploy.tar.gz
"@

Write-Host "🧹 Cleaning up local files..." -ForegroundColor Yellow
Remove-Item pmp-deploy.tar.gz -Force

Write-Host "✅ Deployment completed!" -ForegroundColor Green
Write-Host "🌐 Application available at: http://$Domain" -ForegroundColor Cyan
Write-Host "📊 Check status with: ssh $User@$Server 'pm2 status'" -ForegroundColor Cyan
