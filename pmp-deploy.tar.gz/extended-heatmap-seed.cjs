const { PrismaClient } = require("@prisma/client");

async function extendedHeatmapSeed() {
  const prisma = new PrismaClient();

  try {
    console.log("Starting extended heatmap seed for 500+ tickers...");

    const now = new Date();
    const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    // Get all tickers from database
    const tickers = await prisma.ticker.findMany({
      select: { symbol: true, lastPrice: true, lastChangePct: true }
    });

    console.log(`Found ${tickers.length} tickers in database`);

    // Create SessionPrice and DailyRef records for all tickers
    let processed = 0;
    for (const ticker of tickers) {
      if (!ticker.lastPrice) continue; // Skip tickers without price

      const basePrice = ticker.lastPrice;
      const changePct = ticker.lastChangePct || (Math.random() - 0.5) * 4; // -2% to +2%
      const previousClose = basePrice / (1 + changePct / 100);

      // Create SessionPrice
      await prisma.sessionPrice.upsert({
        where: {
          symbol_date_session: {
            symbol: ticker.symbol,
            date: now,
            session: "regular",
          },
        },
        update: {
          lastPrice: basePrice,
          lastTs: new Date(),
          changePct: changePct,
          source: "polygon",
          quality: "delayed",
          zScore: (Math.random() - 0.5) * 3,
          rvol: 0.8 + Math.random() * 0.4,
        },
        create: {
          symbol: ticker.symbol,
          date: now,
          session: "regular",
          lastPrice: basePrice,
          lastTs: new Date(),
          changePct: changePct,
          source: "polygon",
          quality: "delayed",
          zScore: (Math.random() - 0.5) * 3,
          rvol: 0.8 + Math.random() * 0.4,
        },
      });

      // Create DailyRef
      await prisma.dailyRef.upsert({
        where: {
          symbol_date: {
            symbol: ticker.symbol,
            date: yesterday,
          },
        },
        update: {
          previousClose: previousClose,
          todayOpen: basePrice * (0.99 + Math.random() * 0.02), // Small gap
          regularClose: basePrice,
        },
        create: {
          symbol: ticker.symbol,
          date: yesterday,
          previousClose: previousClose,
          todayOpen: basePrice * (0.99 + Math.random() * 0.02),
          regularClose: basePrice,
        },
      });

      processed++;
      if (processed % 50 === 0) {
        console.log(`Processed ${processed} tickers...`);
      }
    }

    console.log(`✅ Extended heatmap seed completed!`);
    console.log(`📊 Created SessionPrice records: ${processed}`);
    console.log(`📊 Created DailyRef records: ${processed}`);

  } catch (error) {
    console.error("❌ Error in extended heatmap seed:", error);
  } finally {
    await prisma.$disconnect();
  }
}

extendedHeatmapSeed();
