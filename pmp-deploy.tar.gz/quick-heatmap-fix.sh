#!/bin/bash

# Quick Heatmap Fix for SSH Deploy
echo "🔧 Fixing heatmap data..."

cd /var/www/premarketprice

# Create and run heatmap seed
cat > heatmap-fix.cjs << 'EOF'
const { PrismaClient } = require('@prisma/client');

async function fixHeatmap() {
  const prisma = new PrismaClient();
  
  try {
    console.log('🔧 Fixing heatmap data...');
    
    const symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'NVDA'];
    const now = new Date();
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    
    for (const symbol of symbols) {
      const basePrice = symbol === 'NVDA' ? 172.7 : symbol === 'TSLA' ? 217.66 : 150 + Math.random() * 50;
      
      // Create SessionPrice
      await prisma.sessionPrice.upsert({
        where: { 
          symbol_date_session: {
            symbol,
            date: now,
            session: 'regular'
          }
        },
        update: {},
        create: {
          symbol,
          date: now,
          session: 'regular',
          lastPrice: basePrice,
          lastTs: now,
          changePct: (Math.random() - 0.5) * 5,
          source: 'polygon',
          quality: 'delayed',
          zScore: Math.random() * 3 - 1.5,
          rvol: 0.8 + Math.random() * 1.5,
        }
      });
      
      // Create DailyRef
      await prisma.dailyRef.upsert({
        where: {
          symbol_date: {
            symbol,
            date: yesterday
          }
        },
        update: {},
        create: {
          symbol,
          date: yesterday,
          previousClose: basePrice * 0.98,
          todayOpen: basePrice * 0.99,
          regularClose: basePrice,
        }
      });
    }
    
    console.log('✅ Heatmap data fixed!');
    console.log('📊 Created data for symbols:', symbols.join(', '));
    
  } catch (error) {
    console.error('❌ Heatmap fix error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

fixHeatmap();
EOF

echo "🚀 Running heatmap fix..."
node heatmap-fix.cjs

echo "🔄 Restarting application..."
pm2 restart premarketprice

echo "✅ Heatmap fix completed!"
echo "🌐 Check heatmap at: http://89.185.250.213:3000/heatmap"
echo "📊 Check API at: http://89.185.250.213:3000/api/heatmap"
