# Simple PowerShell SSH Deployment
Write-Host "🚀 Starting simple SSH deployment..." -ForegroundColor Green

# Configuration - UPDATE THESE VALUES
$Server = "your-server-ip"
$User = "your-username"
$ProjectPath = "/var/www/pmp-prod"

Write-Host "📤 Uploading files to server..." -ForegroundColor Yellow
# Upload source files (excluding node_modules and .next)
rsync -avz --exclude=node_modules --exclude=.git --exclude=.next --exclude=logs --exclude=test* ./ ${User}@${Server}:${ProjectPath}/

Write-Host "🔧 Installing dependencies and building..." -ForegroundColor Yellow
ssh ${User}@${Server} @"
    cd $ProjectPath
    
    # Install dependencies
    npm ci --production
    
    # Setup database
    mkdir -p data
    cp prisma/data/premarket.db data/premarket.db 2>/dev/null || echo 'Database already exists'
    
    # Generate Prisma client
    npx prisma generate
    
    # Build application
    npm run build
    
    # Start/restart application
    pm2 restart pmp-prod || pm2 start npm --name pmp-prod -- start
"@

Write-Host "✅ Deployment completed!" -ForegroundColor Green
Write-Host "🌐 Application should be available on your server" -ForegroundColor Cyan
