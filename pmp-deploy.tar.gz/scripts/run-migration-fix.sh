ssh root@89.185.250.213 'bash -s' < ./scripts/fix-migrations-and-build.sh
