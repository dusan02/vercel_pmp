#!/bin/bash

# Kompletné riešenie migration problému a build
echo "🔧 === MIGRATION RESET A BUILD ==="
echo "⏰ Čas: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# 1. Reset failed migrations
echo "🗄️ 1. Reset failed migrations:"
npx prisma migrate reset --force --skip-seed
echo "   ✅ Migrations resetované"
echo ""

# 2. Apply all migrations
echo "🔄 2. Apply all migrations:"
npx prisma migrate deploy
echo "   ✅ Migrations aplikované"
echo ""

# 3. Generate Prisma client
echo "🔧 3. Generate Prisma client:"
npx prisma generate
echo "   ✅ Prisma client generovaný"
echo ""

# 4. Build aplikácie
echo "🔨 4. Build aplikácie:"
npm run build
echo "   ✅ Build dokončený"
echo ""

# 5. Reštart aplikácie
echo "🔄 5. Reštart aplikácie:"
pm2 restart premarketprice --update-env
echo "   ✅ Aplikácia reštartovaná"
echo ""

# 6. Status kontrola
echo "📊 6. Status kontrola:"
pm2 status | grep premarketprice
echo ""

echo "🎉 === MIGRATION RESET A BUILD DOKONČENÝ ==="
echo ""
echo "🌐 Testuj aplikáciu: http://89.185.250.213:3000"
echo "📊 Testuj všetky funkcie: ssh root@89.185.250.213 'bash -s' < ./scripts/run-complete-test.sh"
