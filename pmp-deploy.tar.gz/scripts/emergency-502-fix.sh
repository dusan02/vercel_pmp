#!/bin/bash

# Núdzové riešenie 502 Bad Gateway problému
echo "🚨 === NÚDZOVÉ RIEŠENIE 502 BAD GATEWAY ==="
echo "⏰ Čas: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# 1. OKAMŽITÝ REŠTART APLIKÁCIE
echo "🔄 1. Reštart aplikácie:"
pm2 restart premarketprice --update-env
sleep 5
echo "   ✅ Aplikácia reštartovaná"
echo ""

# 2. KONTROLA ZDROJOV
echo "💾 2. Kontrola systémových zdrojov:"
echo "   Memory usage:"
free -h | head -5
echo ""
echo "   CPU usage:"
top -bn1 | grep "Cpu(s)" | head -1
echo ""
echo "   Disk space:"
df -h /var/www/premarketprice
echo ""

# 3. KONTROLA PM2 STATUS
echo "📊 3. PM2 Status:"
pm2 status | grep premarketprice
echo ""

# 4. KONTROLA LOGOV
echo "📋 4. Kontrola error logov:"
pm2 logs premarketprice --lines 10 --err 2>/dev/null || echo "   Žiadne error logy"
echo ""

# 5. TESTOVANIE APLIKÁCIE
echo "🌐 5. Testovanie aplikácie:"
echo "   Testing localhost:3000..."
curl -s -w "Status: %{http_code}\n" "http://localhost:3000/api/health" 2>/dev/null || echo "   ❌ FAILED"
echo ""
echo "   Testing externý prístup..."
curl -s -w "Status: %{http_code}\n" "http://89.185.250.213:3000/api/health" 2>/dev/null || echo "   ❌ FAILED"
echo ""

# 6. VYČISTENIE CACHE AK POTREBNÉ
echo "🧹 6. Vyčistenie cache:"
echo "   Čistením .next cache..."
rm -rf /var/www/premarketprice/.next/cache 2>/dev/null || echo "   Cache neexistuje"
echo ""
echo "   Čistením node_modules cache..."
npm cache clean --force 2>/dev/null || echo "   NPM cache vyčistená"
echo ""

# 7. KONTROLA PORTOV
echo "🔍 7. Kontrola portov:"
netstat -tlnp | grep :3000 || echo "   Port 3000 nie je aktívny"
echo ""

# 8. KONTROLA PROCESOV
echo "🔍 8. Kontrola procesov:"
ps aux | grep premarketprice | head -3
echo ""

# 9. FINÁLNY STATUS
echo "🎯 9. Finálny status:"
if curl -s "http://localhost:3000/api/health" >/dev/null 2>&1; then
    echo "   ✅ Aplikácia funguje LOCALLY"
else
    echo "   ❌ Aplikácia nefunguje ani lokálne"
fi

if curl -s "http://89.185.250.213:3000/api/health" >/dev/null 2>&1; then
    echo "   ✅ Aplikácia funguje EXTERNE"
else
    echo "   ❌ Aplikácia nefunguje externe"
fi

echo ""
echo "💡 ĎALŠIE KROKY AK PROBLÉM PRETRVÁVA:"
echo "   1. Reštart servera: reboot"
echo "   2. Kontrola Nginx: systemctl status nginx"
echo "   3. Kontrola firewall: ufw status"
echo "   4. Full rebuild: npm run build && pm2 restart"
echo "   5. Memory increase: export NODE_OPTIONS='--max-old-space-size=4096'"
echo ""

echo "🎯 === NÚDZOVÉ RIEŠENIE UKONČENÉ ==="
