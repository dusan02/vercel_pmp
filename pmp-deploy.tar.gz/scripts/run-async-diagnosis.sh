ssh root@89.185.250.213 'bash -s' < ./scripts/diagnose-async-error.sh
