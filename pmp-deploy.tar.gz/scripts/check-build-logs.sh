#!/bin/bash

# Detailná kontrola logov pre build problémy
echo "🔍 === KONTROLA LOGOV PRE BUILD PROBLÉMY ==="
echo "⏰ Čas: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# 1. Kontrola npm ci logov
echo "📦 1. npm ci logy:"
echo "   Posledných 20 riadkov npm ci logov..."
if [ -f "/root/.npm/_logs" ]; then
    find /root/.npm/_logs -name "*.log" -exec tail -10 {} \; 2>/dev/null | head -20
else
    echo "   ❌ NPM logy nenájdené"
fi
echo ""

# 2. Kontrola Prisma generate logov
echo "🔧 2. Prisma generate logy:"
echo "   Kontrola Prisma operácií..."
npx prisma migrate status 2>&1 | head -10
echo ""

# 3. Kontrola build logov
echo "🔨 3. Build logy:"
echo "   Posledných 30 riadkov build logov..."
if [ -f "/var/www/premarketprice/.next/build.log" ]; then
    tail -30 /var/www/premarketprice/.next/build.log
else
    echo "   ❌ Build log nenájdený"
fi
echo ""

# 4. Kontrola PM2 logov pred reštartom
echo "📋 4. PM2 logy pred reštartom:"
echo "   Error logy (posledných 20 riadkov)..."
pm2 logs premarketprice --lines 20 --err 2>/dev/null || echo "   ❌ PM2 error logy nedostupné"
echo ""
echo "   Output logy (posledných 20 riadkov)..."
pm2 logs premarketprice --lines 20 --out 2>/dev/null || echo "   ❌ PM2 output logy nedostupné"
echo ""

# 5. Kontrola diskového priestoru
echo "💽 5. Diskový priestor:"
echo "   Kontrola voľného miesta..."
df -h /var/www/premarketprice
echo ""

# 6. Kontrola memory
echo "💾 6. Memory usage:"
echo "   Kontrola pamäte..."
free -h
echo ""

# 7. Kontrola procesov
echo "🔍 7. Procesy:"
echo "   Kontrola bežiacich procesov..."
ps aux | grep -E "(node|npm|prisma)" | head -10
echo ""

# 8. Kontrola environment variables
echo "🔐 8. Environment variables:"
echo "   Kontrola kľúčových premenných..."
echo "   NODE_ENV: $NODE_ENV"
echo "   POLYGON_API_KEY: $(if [ -n "$POLYGON_API_KEY" ]; then echo "✅ Set"; else echo "❌ Missing"; fi)"
echo "   FINNHUB_API_KEY: $(if [ -n "$FINNHUB_API_KEY" ]; then echo "✅ Set"; else echo "❌ Missing"; fi)"
echo ""

# 9. Kontrola SQLite databázy
echo "🗄️ 9. SQLite databáza:"
echo "   Kontrola databázových súborov..."
ls -la /var/www/premarketprice/prisma/data/
echo ""
echo "   Kontrola databázových lockov..."
ls -la /var/www/premarketprice/prisma/data/*.db-journal 2>/dev/null || echo "   ✅ Žiadne databázové locky"
echo ""

echo "🎯 === DIAGNOSTIKA UKONČENÁ ==="
echo ""
echo "💡 MOŽNÉ PROBLÉMY A RIEŠENIA:"
echo "   1. NPM cache problémy: npm cache clean --force"
echo "   2. Prisma migration problémy: npx prisma migrate reset --force"
echo "   3. Build memory problémy: export NODE_OPTIONS='--max-old-space-size=4096'"
echo "   4. Disk space problémy: Vyčistiť staré buildy a logy"
echo "   5. Environment problémy: Skontrolovať .env súbor"
