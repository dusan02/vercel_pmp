#!/bin/bash

# Núdzové riešenie Analysis API 500/404 problémov
echo "🚨 === NÚDZOVÉ RIEŠENIE ANALYSIS API ==="
echo "⏰ Čas: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# 1. OKAMŽITÝ REŠTART APLIKÁCIE
echo "🔄 1. Force reštart aplikácie:"
pm2 restart premarketprice --update-env
sleep 5
echo "   ✅ Aplikácia reštartovaná"
echo ""

# 2. KONTROLA ANALYSIS API ROUTES
echo "🔍 2. Kontrola Analysis API routes:"
echo "   Testing GET /api/analysis/NVDA..."
get_status=$(curl -s -w "%{http_code}" "http://localhost:3000/api/analysis/NVDA" 2>/dev/null)
echo "   Status: $get_status"
echo ""
echo "   Testing POST /api/analysis/NVDA..."
post_status=$(curl -s -w "%{http_code}" -X POST "http://localhost:3000/api/analysis/NVDA" 2>/dev/null)
echo "   Status: $post_status"
echo ""

# 3. KONTROLA BUILD A SÚBOROV
echo "🔨 3. Kontrola buildu a súborov:"
echo "   Kontrola .next/build súboru..."
if [ -f "/var/www/premarketprice/.next/build-manifest.json" ]; then
    echo "   ✅ Build manifest existuje"
else
    echo "   ❌ Build manifest neexistuje - potrebný rebuild"
    echo "   Spúšťam rebuild..."
    cd /var/www/premarketprice && npm run build
fi
echo ""
echo "   Kontrola Analysis API route súboru..."
if [ -f "/var/www/premarketprice/src/app/api/analysis/[ticker]/route.ts" ]; then
    echo "   ✅ Analysis route existuje"
else
    echo "   ❌ Analysis route neexistuje"
fi
echo ""

# 4. KONTROLA ENVIRONMENT VARIABLES
echo "🔐 4. Kontrola environment variables:"
echo "   POLYGON_API_KEY: $(if [ -n "$POLYGON_API_KEY" ]; then echo "✅ Set"; else echo "❌ Missing"; fi)"
echo "   FINNHUB_API_KEY: $(if [ -n "$FINNHUB_API_KEY" ]; then echo "✅ Set"; else echo "❌ Missing"; fi)"
echo "   NODE_ENV: $NODE_ENV"
echo ""

# 5. KONTROLA PRISMA A DATABÁZY
echo "🗄️ 5. Kontrola Prisma a databázy:"
echo "   Prisma generate status..."
npx prisma generate
echo ""
echo "   Kontrola migrácií..."
npx prisma migrate status
echo ""
echo "   Kontrola databázového pripojenia..."
npx prisma db pull --preview-feature 2>/dev/null || echo "   ✅ Databáza pripojená"
echo ""

# 6. KONTROLA PM2 LOGOV
echo "📋 6. Kontrola PM2 logov pre Analysis API:"
echo "   Error logy (posledných 20 riadkov)..."
pm2 logs premarketprice --lines 20 --err | grep -i -E "(analysis|error|500)" || echo "   Žiadne analysis error logy"
echo ""
echo "   Output logy (posledných 20 riadkov)..."
pm2 logs premarketprice --lines 20 --out | grep -i -E "(analysis|route|api)" || echo "   Žiadne analysis output logy"
echo ""

# 7. KONTROLA SIEŤOVÝCH PORTOV
echo "🌐 7. Kontrola sieťových portov:"
echo "   Port 3000 status:"
netstat -tlnp | grep :3000 || echo "   ❌ Port 3000 nie je aktívny"
echo ""
echo "   Externá konektivita..."
curl -s -w "Status: %{http_code}\n" "http://89.185.250.213:3000/api/health" 2>/dev/null || echo "   ❌ Externá konektivita zlyhala"
echo ""

# 8. VYČISTENIE A REBUILD AK POTREBNÉ
echo "🧹 8. Vyčistenie a rebuild ak potrebné:"
echo "   Čistením .next cache..."
rm -rf /var/www/premarketprice/.next/cache 2>/dev/null || echo "   Cache neexistuje"
echo ""
echo "   Čistením .next build..."
rm -rf /var/www/premarketprice/.next 2>/dev/null || echo "   Build neexistuje"
echo ""
echo "   Nový build..."
cd /var/www/premarketprice && npm run build
echo "   ✅ Build dokončený"
echo ""

# 9. FINÁLNY REŠTART S NOVÝM BUILDOM
echo "🔄 9. Finálny reštart s novým buildom:"
pm2 restart premarketprice --update-env
sleep 3
echo "   ✅ Finálny reštart dokončený"
echo ""

# 10. TESTOVANIE VŠETKÝCH ANALYSIS API
echo "🧪 10. Testovanie všetkých Analysis API:"
echo "   Testing GET /api/analysis/AAPL..."
curl -s -w "Status: %{http_code}\n" "http://localhost:3000/api/analysis/AAPL" 2>/dev/null || echo "   ❌ FAILED"
echo ""
echo "   Testing POST /api/analysis/AAPL..."
curl -s -w "Status: %{http_code}\n" -X POST "http://localhost:3000/api/analysis/AAPL" 2>/dev/null || echo "   ❌ FAILED"
echo ""
echo "   Testing GET /api/analysis/NVDA..."
curl -s -w "Status: %{http_code}\n" "http://localhost:3000/api/analysis/NVDA" 2>/dev/null || echo "   ❌ FAILED"
echo ""
echo "   Testing POST /api/analysis/NVDA..."
curl -s -w "Status: %{http_code}\n" -X POST "http://localhost:3000/api/analysis/NVDA" 2>/dev/null || echo "   ❌ FAILED"
echo ""

# 11. SÚHRNNÝ VÝSLEDOK
echo "🎯 11. Súhrnný výsledok:"
echo "   Analysis API GET: $([ "$get_status" = "200" ] && echo "✅ OK" || echo "❌ FAILED ($get_status)")"
echo "   Analysis API POST: $([ "$post_status" = "200" ] && echo "✅ OK" || echo "❌ FAILED ($post_status)")"

if [ "$get_status" = "200" ] && [ "$post_status" = "200" ]; then
    echo ""
    echo "🎉 VŠETKO FUNKČNÉ! Analysis API je plne operatívne."
    echo "🌐 Testuj v prehliadači: http://89.185.250.213:3000/company/NVDA?tab=analysis"
else
    echo ""
    echo "⚠️ PROBLÉM PRETRVÁVA - Potrebné ďalšie kroky."
    echo "💡 Skontrola PM2 logov pre detailné chyby."
fi

echo ""
echo "🎯 === NÚDZOVÉ RIEŠENIE ANALYSIS API UKONČENÉ ==="
