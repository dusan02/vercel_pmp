# Quick SSH Deployment - Ready to use
Write-Host "🚀 Quick SSH Deployment..." -ForegroundColor Green

# UPDATE THESE VALUES:
$Server = "bardusa"  # Tvoj server hostname
$User = "root"      # Tvoj username
$ProjectPath = "/var/www/premarketprice"  # Cesta na serveri

Write-Host "📤 Uploading to $Server..." -ForegroundColor Yellow
# Upload files (excluding unnecessary ones)
rsync -avz --exclude=node_modules --exclude=.git --exclude=.next --exclude=logs --exclude=test* ./ ${User}@${Server}:${ProjectPath}/

Write-Host "🔧 Installing and building on server..." -ForegroundColor Yellow
ssh ${User}@${Server} @"
    cd $ProjectPath
    
    # Install dependencies
    npm ci --production
    
    # Setup database
    mkdir -p data
    cp prisma/data/premarket.db data/premarket.db 2>/dev/null || echo 'Using existing database'
    
    # Generate Prisma client
    npx prisma generate
    
    # Build application
    npm run build
    
    # Start with PM2
    pm2 restart premarketprice || pm2 start npm --name premarketprice -- start
"@

Write-Host "✅ Deployment completed!" -ForegroundColor Green
Write-Host "🌐 Check application at: http://$Server:3000" -ForegroundColor Cyan
Write-Host "📊 Status: ssh $User@$Server 'pm2 status'" -ForegroundColor Cyan
