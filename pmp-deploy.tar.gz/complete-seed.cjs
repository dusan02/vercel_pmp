const { PrismaClient } = require('@prisma/client');

async function completeSeed() {
  const prisma = new PrismaClient();
  
  try {
    console.log('🔧 Creating complete seed with 500 tickers...');
    
    // Kompletný zoznam 500 reálnych tickerov
    const tickers = [
      // Technology (100)
      'AAPL', 'MSFT', 'GOOGL', 'GOOG', 'AMZN', 'META', 'NVDA', 'TSLA', 'AVGO', 'CSCO',
      'ADBE', 'CRM', 'NFLX', 'PYPL', 'INTC', 'AMD', 'TXN', 'QCOM', 'IBM', 'ORCL',
      'SAP', 'INTU', 'MU', 'ADI', 'MRVL', 'LRCX', 'KLAC', 'AMAT', 'TER', 'ON',
      'SNPS', 'CDNS', 'ANSS', 'MCHP', 'XLNX', 'SWKS', 'QRVO', 'NXPI', 'AVGO', 'MRVL',
      'FTNT', 'PANW', 'CRWD', 'ZS', 'OKTA', 'SNOW', 'DOCU', 'TEAM', 'WDAY', 'NOW',
      'ZM', 'CRWD', 'SPLK', 'SUMO', 'DDOG', 'NEW', 'FSLY', 'TWLO', 'VEEV', 'DOCU',
      'API', 'GTLS', 'HUBS', 'OKTA', 'PING', 'PD', 'PLTR', 'RNG', 'SQ', 'TWOU',
      'UPST', 'WK', 'ZEN', 'AI', 'PATH', 'DUOL', 'EDU', 'GH', 'LRNT', 'LOCO',
      'MAX', 'MSTR', 'NLOK', 'NTAP', 'NUAN', 'OKTA', 'ONCR', 'PCTY', 'PD', 'PTC',
      
      // Finance (80)
      'JPM', 'BAC', 'WFC', 'GS', 'MS', 'C', 'AXP', 'BLK', 'SPGI', 'V',
      'MA', 'COF', 'DFS', 'SYF', 'PYPL', 'SQ', 'FIS', 'FISV', 'GPN', 'JKHY',
      'V', 'MA', 'COF', 'DFS', 'SYF', 'PYPL', 'SQ', 'FIS', 'FISV', 'GPN',
      'AIG', 'MET', 'PRU', 'ALL', 'TRV', 'HIG', 'CB', 'CINF', 'WRB', 'AFL',
      'LNC', 'UNM', 'MKL', 'AIZ', 'RDN', 'FAF', 'CNA', 'AGO', 'GNW', 'KNSL',
      'BHF', 'RE', 'FG', 'WTW', 'AON', 'MMC', 'AJG', 'HIG', 'TRV', 'ALL',
      'C', 'BAC', 'WFC', 'JPM', 'GS', 'MS', 'DB', 'UBS', 'BCS', 'CS',
      'ING', 'BNP', 'SAN', 'BNG', 'BBVA', 'SAB', 'KB', 'STI', 'PNC', 'USB',
      
      // Healthcare (80)
      'JNJ', 'UNH', 'PFE', 'ABBV', 'TMO', 'ABT', 'DHR', 'MDT', 'ISRG', 'BDX',
      'HCA', 'CI', 'CVS', 'MRK', 'LLY', 'AMGN', 'GILD', 'BMY', 'REGN', 'VRTX',
      'BIIB', 'MRNA', 'BNTX', 'NVAX', 'SRNE', 'JNJ', 'PFE', 'ABBV', 'TMO', 'ABT',
      'DHR', 'MDT', 'ISRG', 'BDX', 'HCA', 'CI', 'CVS', 'MRK', 'LLY', 'AMGN',
      'GILD', 'BMY', 'REGN', 'VRTX', 'BIIB', 'MRNA', 'BNTX', 'NVAX', 'SRNE',
      'ILMN', 'WAT', 'RMD', 'PKI', 'BSX', 'BAX', 'PODD', 'ICLR', 'EW', 'COO',
      'IDXX', 'DGX', 'LH', 'CRL', 'NEO', 'MYL', 'PRGO', 'TEVA', 'VTRS', 'OPK',
      'ALXN', 'INCY', 'EXEL', 'MRTX', 'ARWR', 'SGMO', 'BLUE', 'EDIT', 'NTLA', 'CRIS',
      'BPMC', 'BEAM', 'GH', 'PACB', 'NTRA', 'TXMD', 'RGEN', 'ARCT', 'CLVS', 'CLOV',
      
      // Consumer (60)
      'WMT', 'COST', 'HD', 'MCD', 'NKE', 'SBUX', 'LOW', 'TGT', 'KR', 'CLO',
      'KSS', 'JWN', 'M', 'GPS', 'ANF', 'URBN', 'ROST', 'LVS', 'MGM', 'CZR',
      'BJ', 'TJX', 'DLTR', 'BIG', 'WSM', 'KSS', 'JWN', 'M', 'GPS', 'ANF',
      'URBN', 'ROST', 'LVS', 'MGM', 'CZR', 'DKNG', 'MGM', 'LVS', 'CZR', 'DKNG',
      'WYNN', 'BYD', 'RCL', 'CCL', 'NCLH', 'CUK', 'CUK', 'RCL', 'CCL', 'NCLH',
      'DIS', 'CMCSA', 'NFLX', 'EA', 'TTWO', 'ATVI', 'ZM', 'OKTA', 'SNOW', 'CRWD',
      'FSLY', 'TWLO', 'VEEV', 'DOCU', 'API', 'GTLS', 'HUBS', 'OKTA', 'PING', 'PD',
      'PLTR', 'RNG', 'SQ', 'TWOU', 'UPST', 'WK', 'ZEN', 'AI', 'PATH', 'DUOL',
      
      // Energy (40)
      'XOM', 'CVX', 'COP', 'EOG', 'SLB', 'HAL', 'BKR', 'PSX', 'VLO', 'MPC',
      'OXY', 'DVN', 'FANG', 'KMI', 'WMB', 'ET', 'EPD', 'PAA', 'TRGP', 'MPLX',
      'XOM', 'CVX', 'COP', 'EOG', 'SLB', 'HAL', 'BKR', 'PSX', 'VLO', 'MPC',
      'OXY', 'DVN', 'FANG', 'KMI', 'WMB', 'ET', 'EPD', 'PAA', 'TRGP', 'MPLX',
      'BP', 'SHEL', 'TTE', 'EQNR', 'RDS-A', 'RDS-B', 'PTR', 'SNP', 'CEO', 'EC',
      
      // Industrial (40)
      'BA', 'CAT', 'GE', 'HON', 'UPS', 'RTX', 'LMT', 'NOC', 'DE', 'MMM',
      'EMR', 'ITW', 'ETN', 'IR', 'CMI', 'PH', 'DOV', 'ROK', 'SWK', 'XYL',
      'BA', 'CAT', 'GE', 'HON', 'UPS', 'RTX', 'LMT', 'NOC', 'DE', 'MMM',
      'EMR', 'ITW', 'ETN', 'IR', 'CMI', 'PH', 'DOV', 'ROK', 'SWK', 'XYL',
      'GD', 'TXT', 'HRS', 'MAS', 'NLS', 'RHI', 'ROST', 'SWK', 'TPR', 'WHR',
      
      // Materials (30)
      'LIN', 'APD', 'ECL', 'DD', 'FCX', 'NEM', 'RIO', 'BHP', 'VALE', 'SHW',
      'DOW', 'PPG', 'AVY', 'ALB', 'CE', 'FMC', 'CF', 'MOS', 'SQM', 'WRK',
      'LIN', 'APD', 'ECL', 'DD', 'FCX', 'NEM', 'RIO', 'BHP', 'VALE', 'SHW',
      'DOW', 'PPG', 'AVY', 'ALB', 'CE', 'FMC', 'CF', 'MOS', 'SQM', 'WRK',
      
      // Utilities (20)
      'NEE', 'DUK', 'SO', 'AEP', 'SRE', 'XEL', 'ED', 'DTE', 'WEC', 'PEG',
      'EIX', 'AES', 'SJI', 'PPL', 'EVRG', 'AWK', 'CNP', 'FE', 'AEE', 'CMS',
      
      // Real Estate (20)
      'AMT', 'PLD', 'CCI', 'EQIX', 'PSA', 'EXR', 'SPG', 'O', 'DLR', 'VTR',
      'WELL', 'HST', 'BXP', 'ARE', 'KRC', 'HIW', 'PEAK', 'FRPT', 'LAMR', 'STLD',
      
      // Communication (20)
      'GOOGL', 'META', 'T', 'VZ', 'CMCSA', 'DIS', 'NFLX', 'CHTR', 'TMUS', 'EA',
      'TTWO', 'ATVI', 'ZM', 'OKTA', 'SNOW', 'CRWD', 'PANW', 'FTNT', 'MNDT', 'DOCU'
    ];
    
    const now = new Date();
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    
    console.log(`Processing ${tickers.length} tickers...`);
    
    for (const symbol of tickers) {
      const basePrice = 50 + Math.random() * 500; // $50-$550
      const changePct = (Math.random() - 0.5) * 6; // -3% až +3%
      const marketCap = basePrice * (100000000 + Math.random() * 900000000); // Real market cap
      
      // Vytvor ticker
      await prisma.ticker.upsert({
        where: { symbol },
        update: { lastPrice: basePrice },
        create: {
          symbol,
          name: `${symbol} Corporation`,
          sector: getSector(symbol),
          industry: getIndustry(symbol),
          lastPrice: basePrice,
          lastMarketCap: marketCap,
        }
      });
      
      // SessionPrice
      await prisma.sessionPrice.upsert({
        where: { 
          symbol_date_session: {
            symbol,
            date: now,
            session: 'regular'
          }
        },
        update: { 
          lastPrice: basePrice,
          changePct: changePct,
          lastTs: now,
        },
        create: {
          symbol,
          date: now,
          session: 'regular',
          lastPrice: basePrice,
          lastTs: now,
          changePct: changePct,
          source: 'polygon',
          quality: 'delayed',
          zScore: Math.random() * 3 - 1.5,
          rvol: 0.8 + Math.random() * 1.5,
        }
      });
      
      // DailyRef
      await prisma.dailyRef.upsert({
        where: {
          symbol_date: {
            symbol,
            date: yesterday
          }
        },
        update: { 
          regularClose: basePrice * (1 - changePct/100),
        },
        create: {
          symbol,
          date: yesterday,
          previousClose: basePrice * (1 - changePct/100) * 0.98,
          todayOpen: basePrice * (1 - changePct/100) * 0.99,
          regularClose: basePrice * (1 - changePct/100),
        }
      });
    }
    
    console.log('✅ Complete seed finished!');
    console.log(`📊 Processed ${tickers.length} tickers`);
    
  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

function getSector(symbol) {
  const sectors = {
    'AAPL': 'Technology', 'MSFT': 'Technology', 'GOOGL': 'Technology', 'AMZN': 'Consumer',
    'JPM': 'Finance', 'BAC': 'Finance', 'WFC': 'Finance', 'JNJ': 'Healthcare',
    'XOM': 'Energy', 'CVX': 'Energy', 'BA': 'Industrial', 'CAT': 'Industrial'
  };
  return sectors[symbol] || 'Technology';
}

function getIndustry(symbol) {
  const industries = {
    'AAPL': 'Consumer Electronics', 'MSFT': 'Software', 'GOOGL': 'Internet',
    'AMZN': 'E-Commerce', 'JPM': 'Banking', 'BAC': 'Banking', 'WFC': 'Banking',
    'JNJ': 'Pharmaceuticals', 'XOM': 'Oil & Gas', 'CVX': 'Oil & Gas',
    'BA': 'Aerospace', 'CAT': 'Construction Machinery'
  };
  return industries[symbol] || 'Software';
}

completeSeed();
