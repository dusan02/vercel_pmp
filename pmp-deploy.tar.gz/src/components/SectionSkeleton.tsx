'use client';

import React from 'react';

interface SectionSkeletonProps {
  rows?: number;
  showHeader?: boolean;
}

export function SectionSkeleton({ rows = 5, showHeader = true }: SectionSkeletonProps) {
  return (
    <div className="section-skeleton">
      {showHeader && (
        <div className="section-skeleton-header">
          <div className="section-skeleton-title" />
        </div>
      )}
      <div className="section-skeleton-content">
        <div className="section-skeleton-table">
          <div className="section-skeleton-row section-skeleton-header-row">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="section-skeleton-cell section-skeleton-header-cell" />
            ))}
          </div>
          {Array.from({ length: rows }).map((_, rowIndex) => (
            <div key={rowIndex} className="section-skeleton-row">
              {Array.from({ length: 8 }).map((_, cellIndex) => (
                <div key={cellIndex} className="section-skeleton-cell" />
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function HeatmapSkeleton() {
  return (
    <div className="heatmap-skeleton w-full h-full bg-black flex flex-col gap-4 rounded-xl overflow-hidden p-1 lg:p-0">
      {/* Skeleton Header - matches HeatmapPreview layout */}
      <div className="hidden lg:flex items-center justify-between mb-4 px-4 pt-4">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 bg-gray-800 rounded-lg animate-pulse" />
          <div className="h-8 w-48 bg-gray-800 rounded-lg animate-pulse" />
        </div>
        <div className="flex items-center gap-3">
          <div className="h-9 w-32 bg-gray-800 rounded-lg animate-pulse" />
          <div className="h-9 w-24 bg-gray-800 rounded-lg animate-pulse" />
        </div>
      </div>

      {/* Skeleton Grid - mimicking a treemap */}
      <div className="flex-1 w-full bg-gray-950/50 rounded-xl overflow-hidden border border-gray-800/50 h-[600px] lg:h-[600px]">
        <div className="grid grid-cols-6 grid-rows-6 gap-1 h-full p-1 lg:p-2">
          {/* Large prominent sectors */}
          <div className="col-span-3 row-span-4 bg-gray-900/80 rounded animate-pulse" />
          <div className="col-span-3 row-span-2 bg-gray-800/60 rounded animate-pulse" />
          <div className="col-span-2 row-span-2 bg-gray-900/40 rounded animate-pulse" />
          <div className="col-span-1 row-span-2 bg-gray-800/50 rounded animate-pulse" />
          
          {/* Smaller sectors */}
          <div className="col-span-2 row-span-2 bg-gray-900/70 rounded animate-pulse" />
          <div className="col-span-2 row-span-1 bg-gray-800/40 rounded animate-pulse" />
          <div className="col-span-2 row-span-1 bg-gray-900/50 rounded animate-pulse" />
          
          <div className="col-span-1 row-span-1 bg-gray-800/60 rounded animate-pulse" />
          <div className="col-span-1 row-span-1 bg-gray-800/30 rounded animate-pulse" />
          <div className="col-span-4 row-span-1 bg-gray-900/20 rounded animate-pulse" />
        </div>
      </div>
    </div>
  );
}

