'use client';

import React from 'react';
import { SortKey } from '@/hooks/useSortableData';
import { MobileSortHeader } from './mobile/MobileSortHeader';

export interface ColumnDef<T> {
    key: string;
    header: React.ReactNode;
    render: (item: T) => React.ReactNode;
    align?: 'left' | 'center' | 'right';
    sortable?: boolean;
    className?: string;
    width?: string;
    showInMobileSort?: boolean;
    mobileWidth?: string;
    /** If true, clicking this cell won't trigger the row's onRowClick */
    disableRowClick?: boolean;
}

interface UniversalTableProps<T> {
    data: T[];
    columns: ColumnDef<T>[];
    keyExtractor: (item: T) => string;
    isLoading?: boolean;
    emptyMessage?: React.ReactNode;
    sortKey?: SortKey | null;
    ascending?: boolean;
    onSort?: (key: SortKey) => void;
    renderMobileCard?: (item: T) => React.ReactNode;
    forceTable?: boolean;
    footer?: React.ReactNode;
    /** Raw <tr> elements to append directly into tbody (avoids td-wrapping a tr) */
    tfootRows?: React.ReactNode;
    /** Callback for when a row is clicked */
    onRowClick?: (item: T) => void;
}

export function UniversalTable<T>({
    data,
    columns,
    keyExtractor,
    isLoading = false,
    emptyMessage = 'No data available.',
    sortKey,
    ascending,
    onSort,
    renderMobileCard,
    forceTable = false,
    footer,
    tfootRows,
    onRowClick
}: UniversalTableProps<T>) {

    if (isLoading) {
        return (
            <div className="flex items-center justify-center p-12">
                <div className="animate-spin h-8 w-8 border-4 border-blue-600 border-t-transparent rounded-full"></div>
            </div>
        );
    }

    const handleSort = (key: string) => {
        if (onSort) {
            onSort(key as SortKey);
        }
    };

    const showMobileCards = !!renderMobileCard && !forceTable;

    return (
        <div className="universal-table-container">
            {/* Mobile Card View (lg:hidden) */}
            {showMobileCards && (
                <div className="lg:hidden w-full">
                    {/* Sort header for mobile cards */}
                    {onSort && sortKey !== undefined && (
                        <MobileSortHeader
                            columns={columns
                                .filter(c => (c.sortable !== false || c.showInMobileSort) && (c.showInMobileSort || !c.className?.includes('hidden')))
                                .map((col, index) => ({
                                    key: `mobile-sort-${index}`,
                                    originalKey: col.key,
                                    label: col.header,
                                    sortable: col.sortable !== false,
                                    align: col.align || 'left',
                                    width: col.mobileWidth || col.width,
                                    ariaLabel: typeof col.header === 'string' ? col.header : (typeof col.key === 'string' ? col.key : `col-${index}`)
                                }))}
                            sortKey={sortKey as string}
                            ascending={ascending ?? false}
                            onSort={handleSort}
                        />
                    )}

                    {data.length === 0 ? (
                        <div className="p-8 text-center text-[var(--clr-subtext)]">
                            {emptyMessage}
                        </div>
                    ) : (
                        <div className="flex flex-col divide-y divide-gray-100 dark:divide-gray-800">
                            {data.map(item => (
                                <React.Fragment key={keyExtractor(item)}>
                                    {renderMobileCard!(item)}
                                </React.Fragment>
                            ))}
                        </div>
                    )}

                    {/* Mobile Footer (e.g. SEO text) - ALWAYS SHOW */}
                    {footer && (
                        <div className="mobile-table-footer">
                            {footer}
                        </div>
                    )}
                </div>
            )}

            {/* Desktop Table View */}
            <div className={`${showMobileCards ? 'hidden lg:block' : ''} overflow-x-auto`}>
                <table className="pmp-universal-table w-full border-collapse">
                    <colgroup>
                        {columns.map((col, index) => (
                            <col key={`col-${col.key}-${index}`} style={col.width ? { width: col.width } : undefined} />
                        ))}
                    </colgroup>
                    <thead>
                        <tr className="border-b border-gray-100 dark:border-gray-800">
                            {columns.map((col, index) => (
                                <th
                                    key={`th-${col.key}-${index}`}
                                    className={`
                                        py-3 px-3 first:pl-4 last:pr-4 font-semibold text-xs md:text-sm whitespace-nowrap
                                        bg-blue-100 text-slate-900 border-b border-blue-200/80
                                        dark:bg-blue-900/60 dark:text-white dark:border-white/10
                                        ${col.sortable ? 'cursor-pointer hover:bg-blue-200/70 dark:hover:bg-white/10 transition-colors select-none' : ''}
                                        ${col.align === 'center' ? 'text-center' : col.align === 'right' ? 'text-right' : 'text-left'}
                                        ${col.className || ''}
                                        ${col.sortable && sortKey === col.key ? 'active-sort' : ''}
                                    `.trim()}
                                    onClick={() => col.sortable && handleSort(col.key)}
                                    style={{ width: col.width }}
                                >
                                    <div className={`flex items-center gap-1 ${col.align === 'center' ? 'justify-center' : col.align === 'right' ? 'justify-end' : 'justify-start'}`}>
                                        {col.header}
                                        {col.sortable && sortKey === col.key && (
                                            <span className="text-[10px] opacity-70">
                                                {ascending ? '▲' : '▼'}
                                            </span>
                                        )}
                                    </div>
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                        {data.length === 0 ? (
                            <tr>
                                <td colSpan={columns.length} className="p-8 text-center text-[var(--clr-subtext)]">
                                    {emptyMessage}
                                </td>
                            </tr>
                        ) : (
                            <>
                                {data.map((item) => (
                                    <tr
                                        key={keyExtractor(item)}
                                        className={`group hover:bg-gray-50 dark:hover:bg-white/5 transition-colors ${onRowClick ? 'cursor-pointer' : ''}`}
                                        onClick={() => onRowClick && onRowClick(item)}
                                    >
                                        {columns.map((col, colIndex) => (
                                            <td
                                                key={`${keyExtractor(item)}-${col.key}-${colIndex}`}
                                                className={`
                                                    py-3 px-3 first:pl-4 last:pr-4 text-sm text-[var(--clr-text)]
                                                    ${col.align === 'center' ? 'text-center' : col.align === 'right' ? 'text-right' : 'text-left'}
                                                    ${col.className || ''}
                                                `.trim()}
                                                onClick={(e) => {
                                                    if (col.disableRowClick) {
                                                        e.stopPropagation();
                                                    }
                                                }}
                                            >
                                                {col.render(item)}
                                            </td>
                                        ))}
                                    </tr>
                                ))}
                            </>
                        )}
                        {footer && (
                            <tr>
                                <td colSpan={columns.length} className="p-0 border-none">
                                    {footer}
                                </td>
                            </tr>
                        )}
                        {tfootRows}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
