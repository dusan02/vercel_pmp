'use client';

import React, { useMemo, useCallback, useLayoutEffect, useRef, useState } from 'react';
import type { CompanyNode } from '@/lib/heatmap/types';
import { formatPrice, formatPercent, formatMarketCap, formatMarketCapDiff } from '@/lib/utils/format';
import { createHeatmapColorScale } from '@/lib/utils/heatmapColors';
import CompanyLogo from './CompanyLogo';
import { BrandLogo } from './BrandLogo';
import { LoginButton } from './LoginButton';
import { computeMobileTreemapSectors, prepareMobileTreemapData } from '@/lib/heatmap/mobileTreemap';
import { getMobileTileLabel, getMobileTileOpticalOffsetPx } from '@/lib/heatmap/mobileLabels';
import { pickCompanyWithHitSlop } from '@/lib/heatmap/mobileHitSlop';
import type { MobileTreemapSectorBlock } from '@/lib/heatmap/mobileTreemap';
import { useUserPreferences } from '@/hooks/useUserPreferences';
import { RotateCcw } from 'lucide-react';

interface MobileTreemapNewProps {
  data: CompanyNode[];
  timeframe?: 'day' | 'week' | 'month';
  metric?: 'percent' | 'mcap';
  onMetricChange?: (metric: 'percent' | 'mcap') => void;
  onTileClick?: (company: CompanyNode) => void;
  onToggleFavorite?: (ticker: string) => void;
  isFavorite?: (ticker: string) => boolean;
  activeView?: string | undefined;
}

// Mobile sector label sizing.
// IMPORTANT UX: tiles should get priority; the sector label should be minimal and not "eat" the heatmap.
// We render the sector label as a small footer under tiles (not above).
const SECTOR_LABEL_H = 14; // px
const SECTOR_LABEL_TOP_DIVIDER_H = 1; // px
const SECTOR_LABEL_TOP_GAP = 4; // px (space between tiles and divider)
const SECTOR_LABEL_BOTTOM_MARGIN = 4; // px (margin below divider/label container)
// We need to account for specific bottom margins/padding in the rendered DOM vs the math here.
// The rendered structure is: Label (14) + Margin-Bottom (4) + Divider (1) + Margin-Bottom (4) -> Tiles.
const SECTOR_CHROME_H = SECTOR_LABEL_H + SECTOR_LABEL_TOP_GAP + SECTOR_LABEL_TOP_DIVIDER_H + SECTOR_LABEL_BOTTOM_MARGIN;

const SECTOR_COL_GAP = 8; // px

export const MobileTreemapNew: React.FC<MobileTreemapNewProps> = ({
  data,
  timeframe = 'day',
  metric = 'percent',
  onMetricChange,
  onTileClick,
  onToggleFavorite,
  isFavorite,
  activeView,
}) => {
  const { preferences } = useUserPreferences();
  const theme = preferences.theme;
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [containerSize, setContainerSize] = useState<{ width: number; height: number }>({ width: 0, height: 0 });

  // Detail panel state
  const [selectedCompany, setSelectedCompany] = useState<CompanyNode | null>(null);
  const closeSheet = useCallback(() => setSelectedCompany(null), []);

  // Sort data
  const sortedData = useMemo(() => {
    return prepareMobileTreemapData(data);
  }, [data]);

  // For easy verification (prod too): how many unique tickers are shown
  const tileCount = sortedData.length;

  // Color scale
  const colorScale = useMemo(() => createHeatmapColorScale(timeframe, metric === 'mcap' ? 'mcap' : 'percent'), [timeframe, metric]);

  const getColor = useCallback((company: CompanyNode): string => {
    if (!company) return '#1a1a1a';
    const value = metric === 'percent'
      ? (company.changePercent ?? 0)
      : (company.marketCapDiff ?? 0);
    return colorScale(value);
  }, [metric, colorScale]);

  const getTileLabel = useCallback((company: CompanyNode, w: number, h: number) => {
    return getMobileTileLabel(company, w, h, metric);
  }, [metric]);


  // Handle container resizing via ResizeObserver
  // IMPORTANT: We only track WIDTH changes. Height must NEVER be updated from observer
  // because this scrollable container grows vertically when D3 inserts tiles, which
  // re-triggers the observer → infinite layout thrashing loop.
  // Initial height is captured once via getBoundingClientRect on mount.
  useLayoutEffect(() => {
    if (!containerRef.current) return;

    // One-time: grab the real available height before D3 mutates the container
    const initialH = containerRef.current.getBoundingClientRect().height;
    setContainerSize(prev =>
      prev.height > 0 ? prev : { width: prev.width, height: initialH }
    );

    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width } = entry.contentRect;
        if (width > 0) {
          setContainerSize(prev => {
            if (prev.width !== width) {
              return { width, height: prev.height }; // height stays frozen — DO NOT update
            }
            return prev;
          });
        }
      }
    });

    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);



  // Build mobile treemap sector blocks (pure helper; no React logic inside)
  const treemapResult = useMemo(() => {
    return computeMobileTreemapSectors(sortedData, containerSize, metric, {
      sectorChromeHeightPx: SECTOR_CHROME_H,
      columnGapPx: SECTOR_COL_GAP,
    });
  }, [sortedData, metric, containerSize]);

  // Direct use of treemapResult.rows.
  const { rows } = treemapResult;

  // Render treemap tiles + sector labels
  const renderHeatmapContent = () => {
    if (!rows || !Array.isArray(rows)) return null;

    return (
      <>
        {rows.map((row) => (
          <div
            key={row.id}
            style={{
              display: 'flex',
              width: '100%',
              height: `${row.height}px`,
              flexShrink: 0, // Prevent row from shrinking and clipping the contained tiles
              gap: `${SECTOR_COL_GAP}px`, // Match D3 calculation instead of hardcoded 4px
            }}
          >
            {row.sectors.map((sector) => (
              <div
                key={sector.name}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  // Use flexBasis + flexShrink:0 so D3's exact pixel widths are honoured.
                  // flexGrow was previously causing flexbox to override D3 calculations and
                  // unevenly inflate one of the columns.
                  flexBasis: `${sector.width}px`,
                  flexShrink: 0,
                  flexGrow: 0,
                  height: '100%',
                  overflow: 'hidden'
                }}
              >
                {/* Sector Label Header (Top) */}
                <div
                  style={{
                    height: `${SECTOR_LABEL_H}px`,
                    padding: '0 4px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'flex-start',
                    fontSize: '10px',
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: '0.06em',
                    color: 'var(--clr-text-secondary)', // Use theme variable instead of hardcoded white
                    lineHeight: 1,
                    marginBottom: `${SECTOR_LABEL_TOP_GAP}px`,
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                  }}
                >
                  {sector.name}
                </div>

                <div
                  style={{
                    height: `${SECTOR_LABEL_TOP_DIVIDER_H}px`,
                    background: 'var(--clr-border)', // Use theme variable
                    marginBottom: `${SECTOR_LABEL_BOTTOM_MARGIN}px`,
                    borderRadius: '1px',
                    opacity: 0.5
                  }}
                />

                {/* Relative Container for D3 Tiles */}
                <div
                  onClickCapture={(e) => {
                    const target = e.target as HTMLElement | null;
                    const isTile = !!target?.closest?.('[data-heatmap-tile="1"]');
                    if (isTile) {
                      const tileEl = target!.closest('[data-heatmap-tile="1"]') as HTMLElement | null;
                      const minDimAttr = tileEl?.getAttribute('data-min-dim');
                      const minDim = minDimAttr ? Number(minDimAttr) : NaN;
                      if (!Number.isFinite(minDim) || minDim >= 22) return;
                    }

                    const rect = (e.currentTarget as HTMLDivElement).getBoundingClientRect();
                    const px = e.clientX - rect.left;
                    const py = e.clientY - rect.top;
                    const picked = pickCompanyWithHitSlop(sector.children, px, py, { radiusPx: 20 });
                    if (!picked) return;

                    e.preventDefault();
                    e.stopPropagation();
                    setSelectedCompany(picked);
                    onTileClick?.(picked);
                  }}
                  style={{
                    position: 'relative',
                    width: '100%',
                    // Explicit height matches D3 exactly — prevents white strips / jagged edges.
                    height: `${sector.tilesHeight}px`,
                  }}
                >
                  {/* Render Tiles */}
                  {sector.children.map((leaf, i: number) => {
                    const company = leaf.company;
                    const color = getColor(company);
                    const x = leaf.x0;
                    const y = leaf.y0;
                    const width = leaf.x1 - leaf.x0;
                    const height = leaf.y1 - leaf.y0;

                    if (width <= 0 || height <= 0) return null;

                    // Semantic Zoom: Use effective size for visibility checks
                    const effectiveScale = Math.max(1, 1); // Fixed zoomScale reference - zoomScale was removed
                    const label = getTileLabel(company, width * effectiveScale, height * effectiveScale);

                    // Center text: remove optical offset for small tiles/fonts to ensure it looks vertically centered
                    // Only use optical offset if we have ample space
                    const labelHeight = (label.symbolFontPx || 0) + (label.showValue ? (label.valueFontPx || 0) : 0);
                    const useOpticalOffset = height > 60 && labelHeight > 20;
                    const opticalOffsetPx = useOpticalOffset ? getMobileTileOpticalOffsetPx(label) : 0;

                    return (
                      <div
                        key={`${company.symbol}-${i}`}
                        role="button"
                        tabIndex={0}
                        data-heatmap-tile="1"
                        data-min-dim={Math.min(width, height)}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedCompany(company);
                          onTileClick?.(company);
                        }}
                        style={{
                          position: 'absolute',
                          left: `${x}px`,
                          top: `${y}px`,
                          width: `${width - 1}px`, // 1px gap creates visual border between tiles
                          height: `${height - 1}px`, // 1px gap creates visual border between tiles
                          background: color,
                          outline: '1px solid rgba(255, 255, 255, 0.55)', // Thin white border, non-overlapping
                          outlineOffset: '-1px',
                          boxSizing: 'border-box',
                          overflow: 'hidden',
                          display: 'flex',
                          flexDirection: 'column',
                          justifyContent: 'center',
                          alignItems: 'center',
                          cursor: 'pointer',
                          zIndex: 1,
                          touchAction: 'pan-y', // Allow vertical scrolling on tiles
                          borderRadius: '1px', // Slight rounding
                        }}
                      >
                        {(label.showSymbol || label.showValue) && (
                          <div
                            style={{
                              // Refactored to Grid centering per user recommendation (Fix #3)
                              // Grid handles sub-pixel all-caps centering better than flex baseline.
                              display: 'grid',
                              placeItems: 'center',
                              alignContent: 'center',
                              height: '100%',
                              width: '100%',
                              position: 'relative',
                              pointerEvents: 'none',
                              textAlign: 'center',
                              lineHeight: '1', // Fixed line-height
                              gap: label.showValue ? 2 : 0,
                              // Apply optical offset via small translation (safer than 50% transform)
                              transform: opticalOffsetPx > 0 ? `translateY(-${opticalOffsetPx}px)` : 'none',
                            }}
                          >
                            {label.showSymbol && (
                              <div
                                style={{
                                  fontSize: `${label.symbolFontPx}px`,
                                  fontWeight: 800,
                                  color: '#ffffff',
                                  textShadow: '0 1px 2px rgba(0,0,0,0.55)',
                                  letterSpacing: '0.01em',
                                  whiteSpace: 'nowrap',
                                  lineHeight: 1,
                                }}
                              >
                                {label.symbol}
                              </div>
                            )}
                            {label.showValue && (
                              <div
                                style={{
                                  fontSize: `${label.valueFontPx}px`,
                                  fontWeight: 600,
                                  color: 'rgba(255, 255, 255, 0.92)',
                                  textShadow: '0 1px 2px rgba(0,0,0,0.45)',
                                  whiteSpace: 'nowrap',
                                  lineHeight: 1,
                                }}
                              >
                                {label.value}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        ))}
      </>
    );
  };

  return (
    <div
      className="flex flex-col w-full bg-[var(--clr-bg)] overflow-hidden"
      style={{
        position: 'relative',
        height: '100%',
        minHeight: '100%',
        zIndex: 1,
      }}
    >
      {/* Header - Relative positioning */}
      <div
        style={{
          position: 'relative',
          zIndex: 100,
          background: 'var(--clr-surface)',
          borderBottom: '1px solid var(--clr-border)',
          padding: '8px 12px',
          paddingTop: 'calc(8px + env(safe-area-inset-top, 0px))',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          flexShrink: 0,
        }}
      >
        <div className="flex items-center gap-2 flex-shrink-0">
          <BrandLogo size={24} />
          <span className="text-[var(--clr-text)] font-bold text-sm tracking-tight">PreMarketPrice</span>

        </div>
        <div className="flex-1" />
        {onMetricChange && (
          <div className="flex items-center bg-white/5 rounded-lg p-1 border border-white/10">
            <button
              type="button"
              onClick={() => onMetricChange('percent')}
              className="px-3 h-8 rounded-md text-xs font-bold transition-all"
              style={{
                background: metric === 'percent' ? '#2563eb' : 'transparent',
                color: metric === 'percent' ? '#ffffff' : '#94a3b8',
                WebkitTapHighlightColor: 'transparent',
              }}
            >
              %
            </button>
            <button
              type="button"
              onClick={() => onMetricChange('mcap')}
              className="px-3 h-8 rounded-md text-xs font-bold transition-all"
              style={{
                background: metric === 'mcap' ? '#2563eb' : 'transparent',
                color: metric === 'mcap' ? '#ffffff' : '#94a3b8',
                WebkitTapHighlightColor: 'transparent',
              }}
            >
              $
            </button>
          </div>
        )}
        <div className="flex-shrink-0 ml-1">
          <LoginButton />
        </div>
      </div>

      {/* Spacer REMOVED */}

      {/* Treemap Container - Segmented Blocks */}
      <div
        ref={containerRef}
        className="mobile-heatmap-scroll"
        style={{
          flex: 1,
          minHeight: 0,
          width: '100%',
          position: 'relative',
          background: 'var(--clr-bg)',
          paddingBottom: '4px', // Standard small padding instead of 80px space
          overflowX: 'hidden',
          overflowY: 'auto', // Enable vertical scrolling
          WebkitOverflowScrolling: 'touch',
        }}
      >
        <div
          style={{
            width: '100%',
            display: 'flex',
            flexDirection: 'column',
            gap: '12px',
            paddingTop: '8px', // Space between header and first category
          }}
        >
          {treemapResult.rows && treemapResult.rows.length > 0 && containerSize.width > 0 ? (
            renderHeatmapContent()
          ) : (


            <div style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '12px',
              height: '100%',
              minHeight: '300px',
              background: 'var(--clr-bg)',
            }}>
              <div
                className="animate-spin rounded-full border-b-2 border-[var(--clr-text)]"
                style={{
                  width: '32px',
                  height: '32px',
                }}
              />
              <span style={{
                color: 'var(--clr-text-secondary)',
                fontSize: '14px',
              }}>
                Loading heatmap...
              </span>
            </div>
          )}
        </div>
      </div >

      {/* Detail Panel - Bottom Sheet (tap on tile) */}
      {
        selectedCompany && (
          <>
            <button
              type="button"
              aria-label="Close details"
              onClick={closeSheet}
              className="fixed inset-0"
              style={{
                background: 'rgba(0,0,0,0.6)',
                zIndex: 9998,
                bottom: 'var(--tabbar-real-h, var(--tabbar-h, 72px))',
                backdropFilter: 'blur(4px)',
                WebkitBackdropFilter: 'blur(4px)',
              }}
            />
            <div
              className="fixed inset-x-0"
              style={{
                zIndex: 10000,
                background: 'var(--clr-surface)',
                color: 'var(--clr-text)',
                borderTopLeftRadius: 20,
                borderTopRightRadius: 20,
                boxShadow: '0 -8px 32px rgba(0,0,0,0.5)',
                padding: '16px',
                maxHeight: 'calc(100dvh - 48px - var(--tabbar-real-h, var(--tabbar-h, 72px)))',
                overflow: 'auto',
                bottom: 'var(--tabbar-real-h, var(--tabbar-h, 72px))',
                WebkitOverflowScrolling: 'touch',
              }}
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <div className="flex-shrink-0">
                    <CompanyLogo ticker={selectedCompany.symbol} size={40} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-lg font-bold leading-tight">
                      {selectedCompany.symbol}
                    </div>
                    <div className="text-xs opacity-70 leading-tight mt-1 truncate">
                      {selectedCompany.sector} · {selectedCompany.industry}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  {onToggleFavorite && (
                    <button
                      type="button"
                      onClick={() => onToggleFavorite(selectedCompany.symbol)}
                      className="w-10 h-10 rounded-lg flex items-center justify-center text-lg transition-colors"
                      style={{
                        background: (isFavorite && isFavorite(selectedCompany.symbol)) ? 'rgba(251,191,36,0.2)' : 'rgba(255,255,255,0.1)',
                        color: (isFavorite && isFavorite(selectedCompany.symbol)) ? '#fbbf24' : '#ffffff',
                        WebkitTapHighlightColor: 'transparent',
                      }}
                      aria-label={(isFavorite && isFavorite(selectedCompany.symbol)) ? 'Remove from favorites' : 'Add to favorites'}
                    >
                      {(isFavorite && isFavorite(selectedCompany.symbol)) ? '★' : '☆'}
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={closeSheet}
                    className="w-10 h-10 rounded-lg flex items-center justify-center text-lg font-semibold transition-colors"
                    style={{
                      background: 'var(--clr-background-muted)',
                      color: 'var(--clr-text)',
                      WebkitTapHighlightColor: 'transparent'
                    }}
                    aria-label="Close"
                  >
                    ✕
                  </button>
                </div>
              </div>

              {/* Data Grid */}
              <div className="grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
                <div className="opacity-70 text-xs">Price</div>
                <div className="text-right font-semibold font-mono tabular-nums">
                  {selectedCompany.currentPrice ? `$${formatPrice(selectedCompany.currentPrice)}` : '—'}
                </div>

                <div className="opacity-70 text-xs">Market Cap</div>
                <div className="text-right font-semibold font-mono tabular-nums">
                  {formatMarketCap(selectedCompany.marketCap ?? 0)}
                </div>

                <div className="opacity-70 text-xs">% Change</div>
                <div
                  className={`text-right font-semibold font-mono tabular-nums ${(selectedCompany.changePercent ?? 0) >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}
                >
                  {formatPercent(selectedCompany.changePercent ?? 0)}
                </div>

                <div className="opacity-70 text-xs">Mcap Δ</div>
                <div
                  className={`text-right font-semibold font-mono tabular-nums ${(selectedCompany.marketCapDiff ?? 0) >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}
                >
                  {selectedCompany.marketCapDiff == null ? '—' : formatMarketCapDiff(selectedCompany.marketCapDiff)}
                </div>
              </div>
            </div>
          </>
        )
      }
    </div >
  );
};
