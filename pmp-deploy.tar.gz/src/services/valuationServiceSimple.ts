import { prisma } from '@/lib/db/prisma';

export interface ValuationDataPoint {
  date: Date;
  value: number;
  percentile?: number | null;
  p10?: number;
  p25?: number;
  p50?: number;
  p75?: number;
  p90?: number;
  period: 'monthly' | 'daily';
}

export interface PercentileStats {
  p10: number;
  p25: number;
  p50: number;
  p75: number;
  p90: number;
  mean: number;
  stdDev: number;
  sampleSize: number;
}

export class ValuationService {
  private static readonly METRICS = ['pe_ratio', 'pb_ratio', 'ps_ratio', 'ev_ebitda'] as const;
  private static readonly PERIODS = ['10y', '5y', '1y', '6m', '3m', '1m'] as const;

  /**
   * Získanie grafových dát pre vizualizáciu
   */
  static async getChartData(
    symbol: string, 
    metric: 'pe_ratio' | 'pb_ratio' | 'ps_ratio' | 'ev_ebitda',
    period: '10y' | '5y' | '1y' = '10y'
  ): Promise<ValuationDataPoint[]> {
    const endDate = new Date();
    const startDate = this.getStartDate(period, endDate);
    
    console.log(`🔍 Searching valuation data for ${symbol} from ${startDate.toISOString()} to ${endDate.toISOString()}`);
    
    // Get historical data directly from DailyValuationHistory
    const historicalData = await prisma.dailyValuationHistory.findMany({
      where: {
        symbol: symbol.toUpperCase(),
        date: {
          gte: startDate,
          lte: endDate
        }
      },
      orderBy: { date: 'asc' },
      take: 1000 // Limit to prevent performance issues
    });
    
    console.log(`📊 Found ${historicalData.length} valuation records for ${symbol}`);
    
    if (historicalData.length === 0) {
      throw new Error(`No valuation data available for this symbol. Please run data collection first.`);
    }
    
    // Map the data to the expected format
    const chartData: ValuationDataPoint[] = historicalData.map(record => {
      let value: number;
      
      switch (metric) {
        case 'pe_ratio':
          value = record.peRatio || 0;
          break;
        case 'pb_ratio':
          value = record.pbRatio || 0;
          break;
        case 'ps_ratio':
          value = record.psRatio || 0;
          break;
        case 'ev_ebitda':
          value = record.evEbitda || 0;
          break;
        default:
          value = 0;
      }
      
      return {
        date: record.date,
        value,
        period: 'daily' as const
      };
    }).filter(point => point.value > 0); // Filter out zero/null values
    
    console.log(`📈 Mapped to ${chartData.length} valid data points for ${symbol} ${metric}`);
    
    if (chartData.length === 0) {
      throw new Error(`No valid ${metric} data found for ${symbol}`);
    }
    
    return chartData;
  }

  /**
   * Helper method to calculate start date based on period
   */
  private static getStartDate(period: string, endDate: Date): Date {
    const startDate = new Date(endDate);
    
    switch (period) {
      case '1y':
        startDate.setFullYear(startDate.getFullYear() - 1);
        break;
      case '5y':
        startDate.setFullYear(startDate.getFullYear() - 5);
        break;
      case '10y':
        startDate.setFullYear(startDate.getFullYear() - 10);
        break;
      default:
        startDate.setFullYear(startDate.getFullYear() - 1);
        break;
    }
    
    return startDate;
  }
}
