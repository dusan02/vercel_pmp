import HomePage from './HomePage';
import { getStocksData } from '@/lib/server/stockService';
import { getEarningsForDate } from '@/lib/server/earningsService';
import { getProjectTickers } from '@/data/defaultTickers';
import { logger } from '@/lib/utils/logger';
import { getDateET, createETDate } from '@/lib/utils/dateET';
import Link from 'next/link';

// Enable ISR (Incremental Static Regeneration) for better performance
// Page is cached and regenerated every 10 seconds
export const revalidate = 10;

// Force dynamic rendering to avoid SSR issues with external API calls
export const dynamic = 'force-dynamic';

export default async function Page() {
  // Server-side data fetching for initial render (SSR)
  // OPTIMIZATION: Prefetch len top 20 pre mobile (rýchlejšie načítanie)
  // Heatmap má vlastné API, takže stocks API môže byť menší
  const project = 'pmp'; // Default project, could be dynamic based on headers/host
  const topTickers = getProjectTickers(project, 20); // Reduced from 30 to 20 for faster mobile load

  let initialData: any[] = [];
  let initialEarningsData = null;

  try {
    const todayET = getDateET(new Date());

    logger.ssr('Fetching initial data for Top 20 tickers and Earnings...');

    // Parallel fetch for speed
    const [stocksResult, earningsResult] = await Promise.allSettled([
      getStocksData(topTickers, project),
      getEarningsForDate(todayET)
    ]);

    if (stocksResult.status === 'fulfilled') {
      initialData = stocksResult.value.data;
      logger.ssr(`Loaded ${initialData.length} stocks`);
    } else {
      logger.error('SSR Error fetching stocks', stocksResult.reason);
      
      // Fallback to demo data
      try {
        const demoResponse = await fetch(`${process.env.NEXTAUTH_URL || 'http://127.0.0.1:3000'}/api/stocks/demo`);
        if (demoResponse.ok) {
          const demoData = await demoResponse.json();
          initialData = demoData.data.slice(0, 20); // Take first 20 for SSR
          logger.ssr(`Loaded ${initialData.length} demo stocks as fallback`);
        }
      } catch (demoError) {
        logger.error('Demo API fallback failed', demoError);
      }
    }

    if (earningsResult.status === 'fulfilled') {
      initialEarningsData = earningsResult.value;
      logger.ssr(`Loaded Earnings for ${todayET}`);
    } else {
      logger.error('SSR Error fetching earnings', earningsResult.reason);
    }

  } catch (error) {
    logger.error('SSR Error fetching initial data', error, { project, tickerCount: topTickers.length });
    // Continue with empty initialData - client side will handle fallback
  }

  return (
    <>
      {/* Server-rendered internal links (helps crawl/discovery even if the main UI is client-heavy) */}
      <nav className="sr-only" aria-label="Primary">
        <Link href="/premarket-movers">Premarket Movers</Link>
        <Link href="/gainers">Top Gainers</Link>
        <Link href="/losers">Top Losers</Link>
        <Link href="/sectors">Sectors</Link>
        <Link href="/stocks">All Stocks</Link>
        <Link href="/heatmap">Heatmap</Link>
        <Link href="/earnings">Earnings Calendar</Link>
      </nav>
      <HomePage initialData={initialData} initialEarningsData={initialEarningsData} />
    </>
  );
}

