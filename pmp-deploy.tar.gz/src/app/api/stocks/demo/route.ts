import { NextResponse } from 'next/server';

// Demo stock data for fallback when Polygon API is unavailable
const demoStocks = [
  { ticker: 'NVDA', companyName: 'NVIDIA', currentPrice: 875.28, change: 15.42, changePercent: 1.79, marketCap: 2150000000000, marketCapDiff: 38000000000 },
  { ticker: 'MSFT', companyName: 'Microsoft', currentPrice: 425.67, change: 3.21, changePercent: 0.76, marketCap: 3160000000000, marketCapDiff: 24000000000 },
  { ticker: 'AAPL', companyName: 'Apple', currentPrice: 178.45, change: -2.33, changePercent: -1.29, marketCap: 2780000000000, marketCapDiff: -36000000000 },
  { ticker: 'GOOGL', companyName: 'Alphabet', currentPrice: 142.89, change: 1.67, changePercent: 1.18, marketCap: 1780000000000, marketCapDiff: 21000000000 },
  { ticker: 'AMZN', companyName: 'Amazon', currentPrice: 145.32, change: 2.45, changePercent: 1.71, marketCap: 1510000000000, marketCapDiff: 25000000000 },
  { ticker: 'META', companyName: 'Meta', currentPrice: 485.93, change: 8.76, changePercent: 1.84, marketCap: 1230000000000, marketCapDiff: 22000000000 },
  { ticker: 'AVGO', companyName: 'Broadcom', currentPrice: 1425.67, change: 12.34, changePercent: 0.87, marketCap: 660000000000, marketCapDiff: 5700000000 },
  { ticker: 'TSLA', companyName: 'Tesla', currentPrice: 245.89, change: -5.67, changePercent: -2.26, marketCap: 780000000000, marketCapDiff: -18000000000 },
  { ticker: 'GOOG', companyName: 'Alphabet', currentPrice: 141.23, change: 1.01, changePercent: 0.72, marketCap: 1760000000000, marketCapDiff: 13000000000 },
  { ticker: 'BRK.B', companyName: 'Berkshire Hathaway', currentPrice: 425.67, change: 2.89, changePercent: 0.68, marketCap: 940000000000, marketCapDiff: 6400000000 },
];

export async function GET() {
  return NextResponse.json({
    success: true,
    data: demoStocks,
    source: 'demo',
    message: 'Demo data - Polygon API key not configured'
  });
}
