# Vytvor deployment package pre SSH
Write-Host "📦 Creating deployment package..." -ForegroundColor Green

# Vytvor zip bez nepotrebných súborov
$excludeFiles = @("node_modules", ".git", ".next", "logs", "test*", "*.log", "coverage", "validation-results.json", "tsconfig.tsbuildinfo", "tsc_errors.log")

# Vytvor zip
Compress-Archive -Path (Get-ChildItem -Recurse | Where-Object { 
    $excludeFiles -notcontains $_.Name -and 
    $_.FullName -notlike "*test*" -and
    $_.FullName -notlike "*check-*" -and
    $_.FullName -notlike "*clean-*" -and
    $_.FullName -notlike "*add-*" -and
    $_.FullName -notlike "*heatmap-*" -and
    $_.FullName -notlike "*valuation-*" -and
    $_.FullName -notlike "*simple-*"
}) -DestinationPath "pmp-deploy.zip" -Force

Write-Host "✅ Package created: pmp-deploy.zip" -ForegroundColor Green
Write-Host "📤 Upload to server: scp pmp-deploy.zip root@bardusa:/tmp/" -ForegroundColor Cyan
Write-Host "🔧 On server: cd /var/www/premarketprice && unzip /tmp/pmp-deploy.zip" -ForegroundColor Cyan
