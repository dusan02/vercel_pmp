#!/bin/bash

# SSH Deployment Script for PMP Production
echo "🚀 Starting SSH deployment..."

# Configuration - UPDATE THESE VALUES
SERVER="your-server-ip"
USER="your-username"
PROJECT_PATH="/var/www/pmp-prod"
DOMAIN="your-domain.com"

echo "📦 Creating deployment package..."
tar -czf pmp-deploy.tar.gz \
    --exclude=node_modules \
    --exclude=.git \
    --exclude=.next \
    --exclude=logs \
    --exclude=test* \
    --exclude=*.log \
    --exclude=coverage \
    --exclude=validation-results.json \
    --exclude=tsconfig.tsbuildinfo \
    --exclude=tsc_errors.log \
    --exclude=test_output.log \
    --exclude=check-*.cjs \
    --exclude=clean-*.cjs \
    --exclude=add-*.cjs \
    --exclude=heatmap-*.cjs \
    --exclude=valuation-*.cjs \
    --exclude=simple-*.cjs \
    --exclude=deploy*.sh \
    --exclude=package-production.json \
    .

echo "📤 Uploading to server..."
scp pmp-deploy.tar.gz $USER@$SERVER:/tmp/

echo "🔧 Deploying on server..."
ssh $USER@$SERVER << 'EOF'
    # Extract deployment
    cd /tmp
    tar -xzf pmp-deploy.tar.gz -C /var/www/pmp-prod/
    
    # Install dependencies
    cd /var/www/pmp-prod
    npm ci --production
    
    # Setup database
    mkdir -p data
    cp prisma/data/premarket.db data/premarket.db
    
    # Generate Prisma client
    npx prisma generate
    
    # Run migrations
    npx prisma migrate deploy
    
    # Seed database
    npm run seed
    
    # Build application
    npm run build
    
    # Restart with PM2
    pm2 restart pmp-prod || pm2 start npm --name pmp-prod -- start
    
    # Cleanup
    rm /tmp/pmp-deploy.tar.gz
EOF

echo "🧹 Cleaning up local files..."
rm pmp-deploy.tar.gz

echo "✅ Deployment completed!"
echo "🌐 Application available at: http://$DOMAIN"
echo "📊 Check status with: ssh $USER@$SERVER 'pm2 status'"
